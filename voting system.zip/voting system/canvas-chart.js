const CHART1 = document.getElementById("lineChart");

Chart.default.global.animation.duration = 200;

let barChart = new Chart(CHART1,{
    type:'bar',
    data:{
        labels: ['ACDP','CDP','DP','P'],
        datasets: [
            {
                data: [10,20,55,30]
            }
        ]
    }
});